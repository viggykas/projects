
// PART B
public class BankSimA5PartB {
	
	

	public static void main(String[] args) {

		CircularQueue BankQ1 = new CircularQueue(100);		//init bank queue
					
		tellers t1 = new tellers(); 						//init three teller desks
		tellers t2 = new tellers();
		tellers t3 = new tellers();
				
		customers cx = new customers();						//customer object init
				
		
		for (int i = 0; i < 100; i++) {	
				
				int cid = cx.newID();								//adding new customer to queue with unique id
				cid++;
				int arrTime = cx.arrivalTime();						//adding random arrival time
				int serTime = cx.serviceTime();						//adding random time until teller serves them
				
				BankQ1.EnQ(cid);
				serTime--;
			
	
		if (serTime == 0){									//if service time is 0, the customer is at front of queue, so take them to the first available teller					
		
			if (!t1.busy()) {
				
				t1.TrTime(cid);
				BankQ1.DeQ();
				serTime--;
				System.out.println("Customer # " + cid + " is at teller 1 \n");
				t1.busy();
				
				
		}
			else if (!t2.busy()) {
			
				t2.TrTime(cid);
				BankQ1.DeQ();
				serTime--;
				System.out.println("Customer # " + cid + " is at teller 2 \n");
				t2.busy();
				
			
		}
		
			else if (!t3.busy()) {
			
				t3.TrTime(cid);
				BankQ1.DeQ();
				serTime--;
				System.out.println("Customer # " + cid + " is at teller 3 \n");
				t3.busy();
				
			
		}
		
		else if (t1.busy()) {
			
				t2.TrTime(cid);
				BankQ1.DeQ();
				serTime--;
				System.out.println("Customer # " + cid + " is at teller 2 \n");
				t2.busy();
			
			
		}		
		
		else if (t2.busy()) {
			
				t3.TrTime(cid);
				BankQ1.DeQ();
				serTime--;
				System.out.println("Customer # " + cid + " is at teller 3 \n");
				t3.busy();
				
					
		}
		
		else if (t3.busy()) {
			
				t1.TrTime(cid);
				BankQ1.DeQ();
				serTime--;
				System.out.println("Customer # " + cid + " is at teller 1 \n");
				t1.busy();
				
					
					if(t1.busy()) {
						t2.TrTime(cid);
						BankQ1.DeQ();
						serTime--;
						System.out.println("Customer # " + cid + " is at teller 2 \n");
						t2.busy();
						
					}
						if (t2.busy()) {
							
							System.out.println("All Tellers busy, please wait.");
							
							serTime--;
						}
				
		}
			else {
			
					System.out.println("All Tellers busy, please wait.");
				
				serTime--;
		}	
			
			
			
		}
				
				
			if (serTime != 0){				// if service time is not 0, reduce the number by one until it is so they will be served by a teller
				
					serTime--;
				
						
						
						
					}
				
				
				
			int avgTime = serTime/100;
			System.out.println("The average wait time is " + avgTime);
			
			}
				
				
		

		
	}
	
}