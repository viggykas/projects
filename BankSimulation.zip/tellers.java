
public class tellers{
	
	
	int trTime;
		
	
		public int TrTime(int cid) {			//function that sets the transaction time to random num between 1 and 5.
			
			trTime = (int)(Math.random() * 5 + 1);
			return trTime;
		
		}
		
		public boolean busy() {					// function to see if teller is busy or not.
			
			
			if (trTime > 0) {
				
				return true;
			}
			else
			return false;
			
		}

		public int freeTeller() {				//function to frees teller from previous customer
			
			trTime = 0;
			return trTime;
			
		}
}

