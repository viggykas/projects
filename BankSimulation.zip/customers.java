
public class customers {
	
	int ID;
	int arrTime = 0;
	int serTime = 0;
	
	
	
	public int newID() {							// return id for each new customer added to queue
		ID = 1;
		return ID++;
	
	}
	
	public int arrivalTime() {						// random arrival time between 1 and 5
		
		arrTime = (int)(Math.random() * 5 + 1);
		return arrTime;
		
	}
	
	public int serviceTime() {						// random time before customer is served, between 1 and 5
		
		serTime = (int)(Math.random() * 5 + 1);
		return serTime;
		
	}
	
	
	
	
	
	
	
	
}



//(int)(Math.random() * 5 + 1);