
// PART A 
public class CircularQueue {	
	
		private int[] queue;

		private int front, rear, size, count;
		

	public CircularQueue (int maxSize)
		{
			queue = new int[maxSize];
		
			this.size = maxSize;
			front = 0;
			rear = -1;
			count = 0;
			
		}
			
	public int QueueSize() {
			
			return count;
			
		}
		
	public int Peek() {
			
			if (isEmpty()) {
				
				System.out.println("Queue is empty, unable to see front element!");			
			}

			return queue[front];
			
		}
		
	public boolean isFull() {
		
	 return (QueueSize() == size);
	
	}
			
	public boolean isEmpty() {
		
		return ( (front == rear+1) && !isFull() );
		
	
	}
		
	public void EnQ(int data) {
		
		
		if(isFull()) {
			
			System.out.println("Queue is full!");
		
			
		}
		
		else 
			System.out.println("Adding customer # " + data + " to queue ");
		rear = (rear + 1) % size;
		
		queue[rear] = data;
		
		count++;	
	}
		
	public void DeQ() {
		
		if (isEmpty()) {
			
			System.out.println("Queue is Empty! ");	
		}
		
		else 
			System.out.println("Removing customer # " + queue[front] + " from queue");
		
		front = (front + 1 ) % size;
		count --;
	
		
	}
	  	
	
	
	public static void main(String[] args) {			//testing queue implementation
		
		CircularQueue Qtest = new CircularQueue(5);		//creating new queue
		
		System.out.println("The size of the queue right now before any additions is " + Qtest.QueueSize());		//testing queue size before changes.
		
		
		Qtest.EnQ(15);						// adding elements to queue
		Qtest.EnQ(16);
		Qtest.EnQ(20);
		Qtest.EnQ(25);
		
		System.out.println("The size of the queue after data entry is " + Qtest.QueueSize());					//testing queue size after data entry
		System.out.println("The element at the top of the queue is " + Qtest.Peek());							// seeing top element of queue BEFORE dequeing

		
		Qtest.DeQ();						// dequeue first element ie FIFO
		
		System.out.println("The element at the top of the queue after DeQueing is " + Qtest.Peek());			// seeing top element of queue AFTER dequeing
		System.out.println("The size of the queue after removing the first element is " + Qtest.QueueSize());	// testing queue size after dequeue
		
		
		Qtest.DeQ();						//dequing to test "isEmpty()" functionality
		Qtest.DeQ();
		Qtest.DeQ();
		Qtest.DeQ();
		
		Qtest.EnQ(15);						//enqueing to test "isFull()" functionality
		Qtest.EnQ(16);
		Qtest.EnQ(20);
		Qtest.EnQ(25);
		Qtest.EnQ(26);
		Qtest.EnQ(30);
		Qtest.EnQ(41);
		
	
		System.out.println("Tested all functions of queue program!");
	}


}



