import java.util.Random;
import java.util.Arrays;


public class Sorting {

	public static void main(String[] args) {
		
		Random rand = new Random();			// init random number object
		
		int [] nArr = new int [21]; 			
		
		
		for (int i = 0; i<20; i++) 	{	
	
			nArr[i] = 500 * (i+1);			//generate 20 multiples of 500 for n values ie 500, 1000, 1500...10000
			
			
		for ( int j = 0; j<nArr.length; j++){		//create array with size nArr and then store random value for each cell
			

			int n = nArr[i];
			
			int [] Ais = new int[n];
			
			Ais[j] = rand.nextInt();
			
			int Ams[] = Ais.clone();		// clone array for merge sort
			
			
			InsertionSort.Insertion(Ais);			// call insertion sort for ais.
			
			MergeSort.mergeSort(Ams, n);			// call merge sort for ams.
			
			
		
	}
		
		
		
		
		}
		

	}

}
